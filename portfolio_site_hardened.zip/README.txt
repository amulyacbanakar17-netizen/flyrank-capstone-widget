Amulya C Banakar portfolio
Live: https://amulyacbanakar17-netizen.github.io/flyrank-capstone-widget/
Includes basic SEO/meta, Open Graph/Twitter share metadata, favicon, working GitHub/email links, and mobile-friendly layout.
